import Link from 'next/link'

export default function Navbar() {
  return (
    <nav className="bg-white border-b border-gray-200">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link href="/" className="text-2xl font-bold text-gray-800 flex items-center gap-2">
          <span>Global Finds</span>
        </Link>
        <div className="space-x-6 text-gray-600 font-medium">
          <Link href="/" className="hover:text-gray-900">Home</Link>
          <Link href="/products" className="hover:text-gray-900">Products</Link>
          <Link href="/stores" className="hover:text-gray-900">Stores</Link>
          <Link href="/about" className="hover:text-gray-900">About</Link>
        </div>
        <div>
          <Link href="/login" className="bg-gray-100 text-gray-800 px-4 py-2 rounded hover:bg-gray-200 border border-gray-300">Sign In</Link>
        </div>
      </div>
    </nav>
  )
}