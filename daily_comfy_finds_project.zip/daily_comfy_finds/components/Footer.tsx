export default function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-400 py-8 mt-12">
      <div className="container mx-auto px-4 text-center">
        <p className="mb-2">Daily Comfy Finds © 2026. All rights reserved.</p>
        <p className="text-sm">Smart Finds for Everyday Life. Better Home | Easier Life | Brighter Days.</p>
      </div>
    </footer>
  )
}