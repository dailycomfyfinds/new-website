const stores = [
  "Amazon (Global)", "AliExpress / Alibaba (Global)", "eBay (Global)", "JD.com (China)", 
  "Walmart.com (Global)", "Mercado Libre (Latin America)", "Rakuten (Japan)", 
  "Shopee (Southeast Asia)", "Shein (Global)", "Temu (Global)", "Etsy (Global)", 
  "Flipkart (India)", "Coupang (South Korea)", "Pinduoduo (China)", "ASOS (Global)", 
  "Zalando (Europe)", "Wayfair (Global)", "Noon (Middle East)", "Trendyol (Turkey)", "Ozon (Russia)"
];

export default function Stores() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-gray-800 mb-8 text-center">Our 20 Supported Stores Worldwide</h1>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stores.map((store, i) => (
          <div key={i} className="bg-white p-4 rounded shadow border border-gray-200 flex items-center justify-center text-center h-24 hover:bg-gray-50 cursor-pointer transition">
            <span className="font-medium text-gray-700">{store}</span>
          </div>
        ))}
      </div>
    </div>
  )
}