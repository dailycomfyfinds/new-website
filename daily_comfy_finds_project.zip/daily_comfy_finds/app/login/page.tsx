'use client';
import { useState } from 'react';

export default function Login() {
  const [email, setEmail] = useState('comfortablefinds@gmail.com');
  const [password, setPassword] = useState('Password@1');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if(email === 'comfortablefinds@gmail.com' && password === 'Password@1') {
      alert('Welcome Admin!');
      window.location.href = '/admin';
    } else {
      alert('Invalid credentials');
    }
  }

  return (
    <div className="flex justify-center items-center min-h-[70vh]">
      <div className="bg-white p-8 rounded-lg shadow-md border border-gray-200 w-full max-w-md">
        <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">Admin Login</h2>
        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-gray-700 mb-1">Email</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} className="w-full border border-gray-300 p-2 rounded focus:outline-none focus:border-gray-500" />
          </div>
          <div>
            <label className="block text-gray-700 mb-1">Password</label>
            <input type="password" value={password} onChange={e => setPassword(e.target.value)} className="w-full border border-gray-300 p-2 rounded focus:outline-none focus:border-gray-500" />
          </div>
          <button type="submit" className="w-full bg-gray-800 text-white py-2 rounded hover:bg-gray-700 transition">Login</button>
        </form>
      </div>
    </div>
  )
}