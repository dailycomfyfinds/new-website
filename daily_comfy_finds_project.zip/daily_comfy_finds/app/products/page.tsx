export default function Products() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-gray-800 mb-6">All Products</h1>
      <div className="flex flex-col md:flex-row gap-8">
        <aside className="w-full md:w-1/4 bg-white p-4 rounded border border-gray-200 h-fit">
          <h2 className="font-bold text-lg mb-4 border-b pb-2">Filters</h2>
          <div className="mb-4">
            <label className="block text-sm text-gray-600 mb-1">Search</label>
            <input type="text" placeholder="Search products..." className="w-full border border-gray-300 rounded p-2" />
          </div>
          <div className="mb-4">
            <label className="block text-sm text-gray-600 mb-1">Store</label>
            <select className="w-full border border-gray-300 rounded p-2 text-gray-700">
              <option>All Stores</option>
              <option>Amazon</option>
              <option>AliExpress</option>
            </select>
          </div>
        </aside>
        <main className="w-full md:w-3/4">
           <div className="bg-white p-4 rounded-lg shadow-md border border-gray-200 flex flex-col md:flex-row gap-6 mb-4">
              <div className="w-full md:w-48 h-48 bg-gray-200 rounded flex items-center justify-center text-gray-500">Image</div>
              <div className="flex-1 flex flex-col justify-center">
                <h3 className="text-xl font-bold text-gray-800">MCGOR 10-inch Rechargeable Motion-Sensor Under-Cabinet Lights</h3>
                <p className="text-gray-500 my-2">motion activated, magnetic mounting, USB-C rechargeable, 5 brightness levels, 2-pack</p>
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-yellow-500 font-bold">★ 4.8</span>
                  <span className="text-sm text-gray-500">(120 Reviews)</span>
                </div>
                <button className="bg-gray-800 text-white px-4 py-2 rounded hover:bg-gray-700 w-max mt-2">View on Amazon</button>
              </div>
           </div>
        </main>
      </div>
    </div>
  )
}