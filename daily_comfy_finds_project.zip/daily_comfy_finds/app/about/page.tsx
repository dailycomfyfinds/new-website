export default function About() {
  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl bg-white shadow-sm mt-8 rounded-lg">
      <h1 className="text-3xl font-bold text-gray-800 mb-6 border-b pb-2">About Daily Comfy Finds (DCF)</h1>
      
      <div className="space-y-8 text-gray-700">
        <section>
          <h2 className="text-xl font-semibold mb-3 text-gray-800">The DCF Method: Six Questions</h2>
          <ul className="list-disc pl-5 space-y-2">
            <li><strong>Value for Money:</strong> Does the value make sense relative to the price?</li>
            <li><strong>Real Utility:</strong> Does it solve a real, recurring problem?</li>
            <li><strong>Practicality:</strong> Is it easy enough to live with?</li>
            <li><strong>Content Potential:</strong> Can it be explained honestly and clearly?</li>
            <li><strong>Demand:</strong> Is there evidence people want this type of solution?</li>
            <li><strong>Women Appeal:</strong> Where relevant, does it solve a meaningful everyday need?</li>
            <li><strong>Outcomes:</strong> PASS / REVIEW / REJECT. Commission never overrides quality.</li>
          </ul>
        </section>

        <section>
          <h2 className="text-xl font-semibold mb-3 text-gray-800">Current Selection: Finds</h2>
          <div className="bg-gray-50 p-4 rounded border">
            <h3 className="font-medium text-gray-900">Product #001: MCGOR 10-inch Rechargeable Motion-Sensor Under-Cabinet Lights</h3>
            <p className="mt-2 text-sm text-gray-600">Identity: MCGOR GLS-C010 · ASIN B0BDF8CVBN</p>
            <p className="text-sm text-gray-600">Features: motion activated, magnetic mounting, USB-C rechargeable, 5 brightness levels, 2-pack</p>
          </div>
        </section>
        
        <section>
          <h2 className="text-xl font-semibold mb-3 text-gray-800">From Product to Learning</h2>
          <ol className="list-decimal pl-5 space-y-1">
            <li><strong>Discover:</strong> Product intake</li>
            <li><strong>Score:</strong> DCF evaluation</li>
            <li><strong>Publish:</strong> Explain first, with trade-offs and affiliate disclosure</li>
            <li><strong>Learn:</strong> Community feedback</li>
          </ol>
        </section>

        <section>
          <h2 className="text-xl font-semibold mb-3 text-gray-800">Trust Center & Compliance</h2>
          <p className="mb-2"><strong>Contact:</strong> comfortablefinds@gmail.com</p>
          <p className="text-sm text-gray-600 italic">
            Affiliate Disclosure: Commission at no extra cost to the visitor. Amazon Associate statement will be displayed where applicable.
          </p>
        </section>
      </div>
    </div>
  )
}