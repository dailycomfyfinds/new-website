export default function AdminDashboard() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-gray-800 mb-8">Admin Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg shadow border border-gray-200">
          <h2 className="text-xl font-bold text-gray-700 mb-2">Manage Products</h2>
          <p className="text-gray-500 mb-4">Add, edit, or remove products and reviews.</p>
          <button className="bg-gray-800 text-white px-4 py-2 rounded w-full">Go to Products</button>
        </div>
        <div className="bg-white p-6 rounded-lg shadow border border-gray-200">
          <h2 className="text-xl font-bold text-gray-700 mb-2">Manage Stores</h2>
          <p className="text-gray-500 mb-4">Manage the 20 global stores and their details.</p>
          <button className="bg-gray-800 text-white px-4 py-2 rounded w-full">Go to Stores</button>
        </div>
        <div className="bg-white p-6 rounded-lg shadow border border-gray-200">
          <h2 className="text-xl font-bold text-gray-700 mb-2">Site Analytics</h2>
          <p className="text-gray-500 mb-4">Track visitor traffic and site growth.</p>
          <button className="bg-gray-800 text-white px-4 py-2 rounded w-full">View Analytics</button>
        </div>
        <div className="bg-white p-6 rounded-lg shadow border border-gray-200">
          <h2 className="text-xl font-bold text-gray-700 mb-2">Customization</h2>
          <p className="text-gray-500 mb-4">Customize colors, cover art effects, and ads.</p>
          <button className="bg-gray-800 text-white px-4 py-2 rounded w-full">Edit Appearance</button>
        </div>
      </div>
    </div>
  )
}