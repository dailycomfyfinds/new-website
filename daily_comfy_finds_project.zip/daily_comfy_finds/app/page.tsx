export default function Home() {
  return (
    <div className="container mx-auto px-4 py-8">
      <header className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-800 mb-4">Discover the World's Best Products</h1>
        <p className="text-gray-600 text-lg">Explore top items from 20 stores worldwide, all in one place.</p>
      </header>
      
      <section className="mb-12">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">Latest Arrivals</h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {/* Placeholder for products */}
          <div className="bg-white p-4 rounded-lg shadow-md border border-gray-200">
            <div className="h-48 bg-gray-300 rounded-md mb-4 flex items-center justify-center text-gray-500">Image</div>
            <h3 className="font-semibold text-gray-800">Smart Fitness Watch</h3>
            <p className="text-gray-600">$129</p>
            <button className="mt-4 w-full bg-gray-800 text-white py-2 rounded-md hover:bg-gray-700">View Details</button>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-md border border-gray-200">
            <div className="h-48 bg-gray-300 rounded-md mb-4 flex items-center justify-center text-gray-500">Image</div>
            <h3 className="font-semibold text-gray-800">Designer Backpack</h3>
            <p className="text-gray-600">$89</p>
            <button className="mt-4 w-full bg-gray-800 text-white py-2 rounded-md hover:bg-gray-700">View Details</button>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-md border border-gray-200">
            <div className="h-48 bg-gray-300 rounded-md mb-4 flex items-center justify-center text-gray-500">Image</div>
            <h3 className="font-semibold text-gray-800">Wireless Earbuds</h3>
            <p className="text-gray-600">$99</p>
            <button className="mt-4 w-full bg-gray-800 text-white py-2 rounded-md hover:bg-gray-700">View Details</button>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-md border border-gray-200">
            <div className="h-48 bg-gray-300 rounded-md mb-4 flex items-center justify-center text-gray-500">Image</div>
            <h3 className="font-semibold text-gray-800">Cozy Knit Blanket</h3>
            <p className="text-gray-600">$75</p>
            <button className="mt-4 w-full bg-gray-800 text-white py-2 rounded-md hover:bg-gray-700">View Details</button>
          </div>
        </div>
      </section>
    </div>
  )
}